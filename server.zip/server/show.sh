#bin/sh

while true
do
	sh showareaparking.sh
	sleep 2
	clear
done
